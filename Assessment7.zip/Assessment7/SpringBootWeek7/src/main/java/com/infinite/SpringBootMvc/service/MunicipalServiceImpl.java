package com.infinite.SpringBootMvc.service;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.infinite.SpringBootMvc.model.Municipal;
import com.infinite.SpringBootMvc.repository.MuniciDAOImpl;
@Service
public class MunicipalServiceImpl implements IMunicipalService {
	@Autowired
	MuniciDAOImpl MunicipalDAOImpl;
	@Override
	@Transactional
	public List<Municipal> getAllComplains() {
		// TODO Auto-generated method stub
		return MunicipalDAOImpl.getAllComplains();
	}
	@Override
	@Transactional
	public Municipal getMunicipal(int id) {
		// TODO Auto-generated method stub
		return MunicipalDAOImpl.getMunicipal(id);
	}
	@Override
	@Transactional
	public Municipal addMunicipal(Municipal municipal) {
		// TODO Auto-generated method stub
		return MunicipalDAOImpl.addMunicipal(municipal);
	}
	@Override
	@Transactional
	public void updateMunicipal(Municipal municipal) {
		// TODO Auto-generated method stub
		MunicipalDAOImpl.updateMunicipal(municipal);
	}
	@Override
	@Transactional
	public void deleteMunicipal(int id) {
		// TODO Auto-generated method stub
		MunicipalDAOImpl.deleteMunicipal(id);
	}
}